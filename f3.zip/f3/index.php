<?php
session_start();

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'borisov2'; 

$conn = mysqli_connect($host, $user, $pass, $dbname);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .page-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
    </style>
</head>
<body>

<header>
    <nav class="nav-links">
        <a href="index.php">Главная</a>
        <a href="auto.php">Авторизация</a>
        <a href="reg.php">Регистрация</a>
        <?php
        if (isset($_SESSION['login']) && !empty($_SESSION['login'])) {
            echo '<a href="profile.php">Профиль</a>';
            echo '<a href="create_request.php">Создание заявки</a>';
            echo '<a href="view_requests.php">Просмотр заявок</a>';
            if ($_SESSION['status'] == 1) {
                echo '<a href="admin.php">Панель администратора</a>';
            }
        }
        ?>
    </nav>
</header>

<div class="main-block page-content">
    
    <h1>Добро пожаловать</h1>
    <p>Это центральный узел вашего сайта по управлению заявками.</p>

    <?php if (isset($_SESSION['login']) && !empty($_SESSION['login'])): ?>
        <p>Вы вошли как: **<?php echo $_SESSION['login']; ?>**</p>
        <form action="auto.php" method="post" style="display:inline-block; margin-left: 15px;">
            <input type="submit" name="out" value="Выход">
        </form>
    <?php else: ?>
        <p>Пожалуйста, <a href="auto.php">авторизуйтесь</a> или <a href="reg.php">зарегистрируйтесь</a>.</p>
    <?php endif; ?>
</div>

<?php
if ($conn) {
    mysqli_close($conn);
}
?>

</body>
</html>